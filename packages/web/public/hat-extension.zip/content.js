let p="https://hat-backend.achim-d87.workers.dev/api";try{chrome.storage.local.get("apiBase",e=>{e.apiBase&&(p=e.apiBase)})}catch{}function M(e,n){if(e<=0||n<=0)return"standard";const t=e/n;return t>=3?"wide":t<=.6?"tall":"standard"}function N(e,n){return n==="wide"&&e.image_wide?e.image_wide:n==="tall"&&e.image_tall?e.image_tall:e.image_url}const o=new Map,g=new WeakSet;let d=[];async function R(){try{return(await(await fetch(`${p}/ads/active`)).json()).ads}catch{return[]}}async function C(){return new Promise(e=>{chrome.storage.local.get("userId",n=>{e(n.userId||"anonymous")})})}async function j(e){try{const n=await C();return(await(await fetch(`${p}/views/start`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:n,adId:e})})).json()).sessionId}catch{return null}}async function I(e){try{const n=await fetch(`${p}/views/end`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:e})});if(n.ok){const t=await n.json();chrome.runtime.sendMessage({type:"UPDATE_EARNINGS",hat:t.hatEarned,usdc:t.usdcEarned}),$()}}catch{}}async function B(e){try{return(await fetch(`${p}/views/heartbeat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:e})})).ok}catch{return!1}}function $(){chrome.storage.local.get(["hatEarned","usdcEarned"],e=>{const n=document.getElementById("hat-session-earnings");n&&(n.textContent=`$${(e.usdcEarned||0).toFixed(4)} USDC · ${Math.floor(e.hatEarned||0)} HAT`)})}const u=new IntersectionObserver(e=>{e.forEach(async n=>{const t=n.target.dataset.adId;if(n.isIntersecting&&!o.has(t)){const a=await j(t);if(a){const i=window.setInterval(async()=>{await B(a)||(clearInterval(i),o.delete(t))},15e3);o.set(t,{sessionId:a,heartbeatTimer:i})}}else if(!n.isIntersecting&&o.has(t)){const a=o.get(t);clearInterval(a.heartbeatTimer),await I(a.sessionId),o.delete(t)}})},{threshold:.5}),D=["#hat-demo-ad","ins.adsbygoogle",'div[id*="google_ads"]','div[id*="div-gpt-ad"]','iframe[src*="doubleclick.net"]','iframe[src*="googlesyndication"]','iframe[id*="google_ads"]','div[class*="ad-container"]','div[class*="ad-wrapper"]','div[class*="ad-slot"]','div[class*="ad-banner"]','div[class*="ad-unit"]','div[class*="advertisement"]','div[id*="ad-container"]','div[id*="ad-wrapper"]','div[id*="ad-slot"]','div[id*="ad-banner"]','div[id*="advertisement"]','aside[class*="ad"]','section[class*="ad-"]',"div[data-ad]","div[data-ad-slot]","div[data-ad-unit]","div[data-adunit]",'div[class*="amzn-ad"]',"#carbonads",".carbonad","#bsap",".bsa-cpc",'div[id*="media_net"]','div[class*="taboola"]','div[class*="outbrain"]','div[id*="taboola"]','div[id*="outbrain"]',"div.sevioads",'div[id^="wrapper-sevio"]','div[id^="sevio_iframe"]','div[id^="sevio-ad"]','iframe[src*="adx.ws"]','iframe[id*="tb-iframe"]',"#ad-container"],x=D.join(", "),z=new Set(["728x90","300x250","160x600","320x50","320x100","970x250","336x280","300x600","970x90","250x250","200x200","468x60","120x600","320x480","300x50","300x100","970x66"]);function P(e){var r;const n=e.width||String(e.offsetWidth),t=e.height||String(e.offsetHeight);if(z.has(`${n}x${t}`))return!0;const a=e.src||"";if(a.startsWith("data:")&&a.length>200||/ad[sx]?\.|banner|sponsor|promo|click|track|doubleclick|googlesyndication|adx\.ws|sevio/i.test(a))return!0;const i=e.parentElement;return!!(i&&((r=i.matches)!=null&&r.call(i,x)))}const k=12e3,b=600,f=[];let A=null;function U(e){const n=[...e];for(let t=n.length-1;t>0;t--){const a=Math.floor(Math.random()*(t+1));[n[t],n[a]]=[n[a],n[t]]}return n}function v(e,n,t){if(n===0)return[];if(n===1)return Array(e).fill(0);const a=U([...Array(n).keys()]),i=[],r=new Set;for(let s=0;s<e;s++){let l=a.find(c=>!r.has(c)&&c!==t[s]);l===void 0&&(l=a.find(c=>!r.has(c))),l===void 0&&(r.clear(),l=a.find(c=>c!==t[s])??a[0]),i.push(l),r.add(l)}return i}function W(e){const n=["#818cf8","#fb7185","#fbbf24"],t=n[Math.abs(V(e.id))%n.length];return`
    <a href="${e.target_url}" target="_blank" rel="noopener"
      style="display:flex;align-items:center;width:100%;height:100%;padding:0 16px;gap:12px;
        text-decoration:none;border-radius:10px;overflow:hidden;">
      <div style="flex-shrink:0;width:28px;height:28px;border-radius:8px;
        background:linear-gradient(135deg,${t},rgba(255,255,255,0.06));
        display:flex;align-items:center;justify-content:center;
        border:1px solid rgba(255,255,255,0.1);">
        <span style="font-weight:900;font-size:11px;color:#fff;font-family:system-ui;">H</span>
      </div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:13px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:system-ui,-apple-system,sans-serif;">
          ${e.title}
        </div>
      </div>
      <div style="flex-shrink:0;padding:6px 14px;border-radius:8px;
        background:linear-gradient(135deg,${t},rgba(255,255,255,0.05));
        font-size:11px;font-weight:700;color:#fff;font-family:system-ui;white-space:nowrap;
        border:1px solid rgba(255,255,255,0.08);">
        Learn More
      </div>
      <div style="flex-shrink:0;font-size:9px;color:rgba(255,255,255,0.3);font-family:system-ui;
        padding-left:8px;border-left:1px solid rgba(255,255,255,0.06);white-space:nowrap;">
        HAT Ad
      </div>
    </a>
  `}function _(e,n="standard"){if(n==="wide")return W(e);const t=N(e,n);return`
    <a href="${e.target_url}" target="_blank" rel="noopener" style="display:block;width:100%;height:100%;border-radius:12px;overflow:hidden;">
      <img src="${t}" alt="${e.title}"
        style="width:100%;height:100%;object-fit:contain;transition:transform .2s,filter .2s;"
        onmouseenter="this.style.transform='scale(1.02)';this.style.filter='brightness(1.05)'"
        onmouseleave="this.style.transform='none';this.style.filter='none'" />
    </a>
    <div style="position:absolute;bottom:6px;right:8px;font-size:10px;color:rgba(255,255,255,0.7);
      background:rgba(15,11,46,0.65);backdrop-filter:blur(8px);padding:3px 8px;border-radius:8px;
      border:1px solid rgba(255,255,255,0.08);font-weight:500;">
      HAT · ${e.title}
    </div>
  `}function V(e){let n=0;for(let t=0;t<e.length;t++)n=(n<<5)-n+e.charCodeAt(t)|0;return n}function q(e,n="standard",t){const a=document.createElement("div");return a.className="hat-replaced-ad",a.dataset.adId=e.id,a.style.cssText=`
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    overflow:hidden;border-radius:12px;border:1px solid rgba(99,102,241,0.15);
    background:rgba(15,11,46,0.96);backdrop-filter:blur(8px);
    box-shadow:0 2px 12px rgba(99,102,241,0.06);position:relative;
    transition:opacity ${b}ms ease;
    ${t?`width:${t.width};height:${t.height};`:"padding:12px;"}
  `,a.innerHTML=_(e,n),a}function F(e,n){const t=e.container,a=t.dataset.adId;if(o.has(a)){const i=o.get(a);clearInterval(i.heartbeatTimer),I(i.sessionId),o.delete(a)}t.style.opacity="0",setTimeout(()=>{t.dataset.adId=n.id,t.innerHTML=_(n,e.shape),t.style.opacity="1",u.unobserve(t),u.observe(t)},b)}function J(){if(d.length<=1||f.length===0)return;const e=f.map(t=>t.adIndex),n=v(f.length,d.length,e);f.forEach((t,a)=>{const i=n[a];i!==t.adIndex&&setTimeout(()=>{t.adIndex=i,F(t,d[i])},a*150)})}function G(){A===null&&(A=window.setInterval(J,k))}function Y(e){var E,T;if(g.has(e)||d.length===0||(E=e.closest)!=null&&E.call(e,"#hat-sidebar")||(T=e.classList)!=null&&T.contains("hat-replaced-ad"))return;const n=e.getBoundingClientRect(),t=n.width||e.offsetWidth||0,a=n.height||e.offsetHeight||0,i=f.map(L=>L.adIndex),s=v(1,d.length,i)[0],l=d[s],c=t>10&&a>10?{width:`${t}px`,height:`${a}px`}:void 0,S=M(t,a),m=q(l,S,c);g.add(m);const O={container:m,adIndex:s,shape:S,size:c};f.push(O),e.replaceWith(m),u.observe(m),G()}function w(){if(d.length===0)return;const e=new Set;document.querySelectorAll(x).forEach(n=>{g.has(n)||e.add(n)}),document.querySelectorAll("iframe").forEach(n=>{var a;if(g.has(n)||!P(n))return;const t=n.parentElement;t&&((a=t.matches)!=null&&a.call(t,x))&&!g.has(t)?e.add(t):e.add(n)});for(const n of e){let t=!1;for(const a of e)if(a!==n&&a.contains(n)){t=!0;break}t||Y(n)}}let y=!1;function Z(){y||(y=!0,requestAnimationFrame(()=>{w(),y=!1}))}const K=new MutationObserver(e=>{for(const n of e)if(n.addedNodes.length>0||n.type==="attributes"){Z();return}}),h=[];function H(e){return`
    <a href="${e.target_url}" target="_blank">
      <img src="${e.image_url}" alt="${e.title}" />
    </a>
    <div class="hat-ad-label">${e.title}</div>
  `}function Q(){if(d.length<=1||h.length===0)return;const e=h.map(t=>t.adIndex),n=v(h.length,d.length,e);h.forEach((t,a)=>{const i=n[a];i!==t.adIndex&&setTimeout(()=>{const r=t.el.dataset.adId;if(o.has(r)){const s=o.get(r);clearInterval(s.heartbeatTimer),I(s.sessionId),o.delete(r)}t.el.style.opacity="0",t.el.style.transform="translateY(4px)",setTimeout(()=>{const s=d[i];t.adIndex=i,t.el.dataset.adId=s.id,t.el.innerHTML=H(s),t.el.style.opacity="1",t.el.style.transform="none",u.unobserve(t.el),u.observe(t.el)},b)},a*200)})}function X(e){const n=document.createElement("div");n.id="hat-sidebar";const t=Math.min(3,e.length),a=v(t,e.length,[]);n.innerHTML=`
    <div class="hat-header">
      <span>HAT</span>
      <span id="hat-session-earnings" style="font-size:12px;font-weight:600;color:#fbbf24;">$0.00 USDC · 0 HAT</span>
    </div>
    <div class="hat-earnings">Earning USDC nanopayments + HAT bonus</div>
  `;for(let i=0;i<t;i++){const r=e[a[i]],s=document.createElement("div");s.className="hat-ad-slot",s.dataset.adId=r.id,s.style.cssText=`transition: opacity ${b}ms ease, transform ${b}ms ease;`,s.innerHTML=H(r),n.appendChild(s),h.push({el:s,adIndex:a[i]})}document.body.appendChild(n),document.body.classList.add("hat-active"),$(),h.forEach(i=>u.observe(i.el)),setInterval(Q,k)}window.addEventListener("beforeunload",()=>{o.forEach(({sessionId:e,heartbeatTimer:n})=>{clearInterval(n),navigator.sendBeacon(`${p}/views/end`,JSON.stringify({sessionId:e}))})});(async()=>(d=await R(),d.length!==0&&(X(d),w(),K.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","id","data-ad","data-ad-slot"]}),setInterval(w,8e3))))();
