let f="https://hat-backend.achim-d87.workers.dev/api";try{chrome.storage.local.get("apiBase",e=>{e.apiBase&&(f=e.apiBase)})}catch{}function N(e,n){if(e<=0||n<=0)return"standard";const t=e/n;return t>=3?"wide":t<=.6?"tall":"standard"}function C(e,n){return n==="wide"&&e.image_wide?e.image_wide:n==="tall"&&e.image_tall?e.image_tall:e.image_url}const o=new Map,p=new WeakSet;let d=[];async function j(){try{return(await(await fetch(`${f}/ads/active`)).json()).ads}catch{return[]}}async function E(){return new Promise(e=>{chrome.storage.local.get("userId",n=>{e(n.userId||"anonymous")})})}async function B(e){try{const n=await E();return(await(await fetch(`${f}/views/start`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:n,adId:e})})).json()).sessionId}catch{return null}}async function S(e){try{const n=await fetch(`${f}/views/end`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:e})});if(n.ok){const t=await n.json();chrome.runtime.sendMessage({type:"UPDATE_EARNINGS",hat:t.hatEarned,usdc:t.usdcEarned}),v()}}catch{}}async function D(e,n){try{const t=await E(),a=await fetch(`${f}/views/click`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:t,adId:e,sessionId:n})});if(a.ok){const s=await a.json();s.usdcReward>0&&(chrome.runtime.sendMessage({type:"UPDATE_EARNINGS",hat:s.hatReward,usdc:s.usdcReward}),v())}}catch{}}async function U(e){try{return(await fetch(`${f}/views/heartbeat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:e})})).ok}catch{return!1}}function v(){chrome.storage.local.get(["hatEarned","usdcEarned"],e=>{const n=document.getElementById("hat-session-earnings");n&&(n.textContent=`$${(e.usdcEarned||0).toFixed(4)} USDC · ${Math.floor(e.hatEarned||0)} HAT`)})}async function $(){try{const e=await E();if(e==="anonymous")return;const n=await fetch(`${f}/auth/user/${e}`);if(!n.ok)return;const t=await n.json();t.totalUsdcEarned!==void 0&&(chrome.storage.local.set({usdcEarned:t.totalUsdcEarned,hatEarned:t.totalHatEarned}),v())}catch{}}const g=new IntersectionObserver(e=>{e.forEach(async n=>{const t=n.target.dataset.adId;if(n.isIntersecting&&!o.has(t)){const a=await B(t);if(a){const s=window.setInterval(async()=>{await U(a)||(clearInterval(s),o.delete(t))},15e3);o.set(t,{sessionId:a,heartbeatTimer:s})}}else if(!n.isIntersecting&&o.has(t)){const a=o.get(t);clearInterval(a.heartbeatTimer),await S(a.sessionId),o.delete(t)}})},{threshold:.5}),P=["#hat-demo-ad","ins.adsbygoogle",'div[id*="google_ads"]','div[id*="div-gpt-ad"]','iframe[src*="doubleclick.net"]','iframe[src*="googlesyndication"]','iframe[id*="google_ads"]','div[class*="ad-container"]','div[class*="ad-wrapper"]','div[class*="ad-slot"]','div[class*="ad-banner"]','div[class*="ad-unit"]','div[class*="advertisement"]','div[id*="ad-container"]','div[id*="ad-wrapper"]','div[id*="ad-slot"]','div[id*="ad-banner"]','div[id*="advertisement"]','aside[class*="ad"]','section[class*="ad-"]',"div[data-ad]","div[data-ad-slot]","div[data-ad-unit]","div[data-adunit]",'div[class*="amzn-ad"]',"#carbonads",".carbonad","#bsap",".bsa-cpc",'div[id*="media_net"]','div[class*="taboola"]','div[class*="outbrain"]','div[id*="taboola"]','div[id*="outbrain"]',"div.sevioads",'div[id^="wrapper-sevio"]','div[id^="sevio_iframe"]','div[id^="sevio-ad"]','iframe[src*="adx.ws"]','iframe[id*="tb-iframe"]',"#ad-container"],x=P.join(", "),z=new Set(["728x90","300x250","160x600","320x50","320x100","970x250","336x280","300x600","970x90","250x250","200x200","468x60","120x600","320x480","300x50","300x100","970x66"]);function W(e){var r;const n=e.width||String(e.offsetWidth),t=e.height||String(e.offsetHeight);if(z.has(`${n}x${t}`))return!0;const a=e.src||"";if(a.startsWith("data:")&&a.length>200||/ad[sx]?\.|banner|sponsor|promo|click|track|doubleclick|googlesyndication|adx\.ws|sevio/i.test(a))return!0;const s=e.parentElement;return!!(s&&((r=s.matches)!=null&&r.call(s,x)))}const H=12e3,m=600,u=[];let _=null;function F(e){const n=[...e];for(let t=n.length-1;t>0;t--){const a=Math.floor(Math.random()*(t+1));[n[t],n[a]]=[n[a],n[t]]}return n}function y(e,n,t){if(n===0)return[];if(n===1)return Array(e).fill(0);const a=F([...Array(n).keys()]),s=[],r=new Set;for(let i=0;i<e;i++){let l=a.find(c=>!r.has(c)&&c!==t[i]);l===void 0&&(l=a.find(c=>!r.has(c))),l===void 0&&(r.clear(),l=a.find(c=>c!==t[i])??a[0]),s.push(l),r.add(l)}return s}function J(e){const n=["#818cf8","#fb7185","#fbbf24"],t=n[Math.abs(V(e.id))%n.length];return`
    <a href="${e.target_url}" target="_blank" rel="noopener"
      style="display:flex;align-items:center;width:100%;height:100%;padding:0 16px;gap:12px;
        text-decoration:none;border-radius:10px;overflow:hidden;">
      <div style="flex-shrink:0;width:28px;height:28px;border-radius:8px;
        background:linear-gradient(135deg,${t},rgba(255,255,255,0.06));
        display:flex;align-items:center;justify-content:center;
        border:1px solid rgba(255,255,255,0.1);">
        <span style="font-weight:900;font-size:11px;color:#fff;font-family:system-ui;">H</span>
      </div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:13px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:system-ui,-apple-system,sans-serif;">
          ${e.title}
        </div>
      </div>
      <div style="flex-shrink:0;padding:6px 14px;border-radius:8px;
        background:linear-gradient(135deg,${t},rgba(255,255,255,0.05));
        font-size:11px;font-weight:700;color:#fff;font-family:system-ui;white-space:nowrap;
        border:1px solid rgba(255,255,255,0.08);">
        Learn More
      </div>
      <div style="flex-shrink:0;font-size:9px;color:rgba(255,255,255,0.3);font-family:system-ui;
        padding-left:8px;border-left:1px solid rgba(255,255,255,0.06);white-space:nowrap;">
        HAT Ad
      </div>
    </a>
  `}function O(e,n="standard"){if(n==="wide")return J(e);const t=C(e,n);return`
    <a href="${e.target_url}" target="_blank" rel="noopener" style="display:block;width:100%;height:100%;border-radius:12px;overflow:hidden;">
      <img src="${t}" alt="${e.title}"
        style="width:100%;height:100%;object-fit:contain;transition:transform .2s,filter .2s;"
        onmouseenter="this.style.transform='scale(1.02)';this.style.filter='brightness(1.05)'"
        onmouseleave="this.style.transform='none';this.style.filter='none'" />
    </a>
    <div style="position:absolute;bottom:6px;right:8px;font-size:10px;color:rgba(255,255,255,0.7);
      background:rgba(15,11,46,0.65);backdrop-filter:blur(8px);padding:3px 8px;border-radius:8px;
      border:1px solid rgba(255,255,255,0.08);font-weight:500;">
      HAT · ${e.title}
    </div>
  `}function V(e){let n=0;for(let t=0;t<e.length;t++)n=(n<<5)-n+e.charCodeAt(t)|0;return n}function q(e,n="standard",t){const a=document.createElement("div");return a.className="hat-replaced-ad",a.dataset.adId=e.id,a.style.cssText=`
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    overflow:hidden;border-radius:12px;border:1px solid rgba(99,102,241,0.15);
    background:rgba(15,11,46,0.96);backdrop-filter:blur(8px);
    box-shadow:0 2px 12px rgba(99,102,241,0.06);position:relative;
    transition:opacity ${m}ms ease;
    ${t?`width:${t.width};height:${t.height};`:"padding:12px;"}
  `,a.innerHTML=O(e,n),a.addEventListener("click",s=>{const r=s.target.closest("a");if(r&&r.href){const i=o.get(e.id);D(e.id,i==null?void 0:i.sessionId)}}),a}function G(e,n){const t=e.container,a=t.dataset.adId;if(o.has(a)){const s=o.get(a);clearInterval(s.heartbeatTimer),S(s.sessionId),o.delete(a)}t.style.opacity="0",setTimeout(()=>{t.dataset.adId=n.id,t.innerHTML=O(n,e.shape),t.style.opacity="1",g.unobserve(t),g.observe(t)},m)}function Y(){if(d.length<=1||u.length===0)return;const e=u.map(t=>t.adIndex),n=y(u.length,d.length,e);u.forEach((t,a)=>{const s=n[a];s!==t.adIndex&&setTimeout(()=>{t.adIndex=s,G(t,d[s])},a*150)})}function Z(){_===null&&(_=window.setInterval(Y,H))}function K(e){var A,k;if(p.has(e)||d.length===0||(A=e.closest)!=null&&A.call(e,"#hat-sidebar")||(k=e.classList)!=null&&k.contains("hat-replaced-ad"))return;const n=e.getBoundingClientRect(),t=n.width||e.offsetWidth||0,a=n.height||e.offsetHeight||0,s=u.map(M=>M.adIndex),i=y(1,d.length,s)[0],l=d[i],c=t>10&&a>10?{width:`${t}px`,height:`${a}px`}:void 0,T=N(t,a),b=q(l,T,c);p.add(b);const L={container:b,adIndex:i,shape:T,size:c};u.push(L),e.replaceWith(b),g.observe(b),Z()}function I(){if(d.length===0)return;const e=new Set;document.querySelectorAll(x).forEach(n=>{p.has(n)||e.add(n)}),document.querySelectorAll("iframe").forEach(n=>{var a;if(p.has(n)||!W(n))return;const t=n.parentElement;t&&((a=t.matches)!=null&&a.call(t,x))&&!p.has(t)?e.add(t):e.add(n)});for(const n of e){let t=!1;for(const a of e)if(a!==n&&a.contains(n)){t=!0;break}t||K(n)}}let w=!1;function Q(){w||(w=!0,requestAnimationFrame(()=>{I(),w=!1}))}const X=new MutationObserver(e=>{for(const n of e)if(n.addedNodes.length>0||n.type==="attributes"){Q();return}}),h=[];function R(e){return`
    <a href="${e.target_url}" target="_blank">
      <img src="${e.image_url}" alt="${e.title}" />
    </a>
    <div class="hat-ad-label">${e.title}</div>
  `}function ee(){if(d.length<=1||h.length===0)return;const e=h.map(t=>t.adIndex),n=y(h.length,d.length,e);h.forEach((t,a)=>{const s=n[a];s!==t.adIndex&&setTimeout(()=>{const r=t.el.dataset.adId;if(o.has(r)){const i=o.get(r);clearInterval(i.heartbeatTimer),S(i.sessionId),o.delete(r)}t.el.style.opacity="0",t.el.style.transform="translateY(4px)",setTimeout(()=>{const i=d[s];t.adIndex=s,t.el.dataset.adId=i.id,t.el.innerHTML=R(i),t.el.style.opacity="1",t.el.style.transform="none",g.unobserve(t.el),g.observe(t.el)},m)},a*200)})}function te(e){const n=document.createElement("div");n.id="hat-sidebar";const t=Math.min(3,e.length),a=y(t,e.length,[]);n.innerHTML=`
    <div class="hat-header">
      <span>HAT</span>
      <span id="hat-session-earnings" style="font-size:12px;font-weight:600;color:#fbbf24;">$0.00 USDC · 0 HAT</span>
    </div>
    <div class="hat-earnings">Earning USDC nanopayments + HAT bonus</div>
  `;for(let s=0;s<t;s++){const r=e[a[s]],i=document.createElement("div");i.className="hat-ad-slot",i.dataset.adId=r.id,i.style.cssText=`transition: opacity ${m}ms ease, transform ${m}ms ease;`,i.innerHTML=R(r),n.appendChild(i),h.push({el:i,adIndex:a[s]})}document.body.appendChild(n),document.body.classList.add("hat-active"),v(),h.forEach(s=>g.observe(s.el)),setInterval(ee,H)}window.addEventListener("beforeunload",()=>{o.forEach(({sessionId:e,heartbeatTimer:n})=>{clearInterval(n),navigator.sendBeacon(`${f}/views/end`,JSON.stringify({sessionId:e}))})});(async()=>(d=await j(),d.length!==0&&(te(d),$(),setInterval($,3e4),I(),X.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","id","data-ad","data-ad-slot"]}),setInterval(I,8e3))))();
